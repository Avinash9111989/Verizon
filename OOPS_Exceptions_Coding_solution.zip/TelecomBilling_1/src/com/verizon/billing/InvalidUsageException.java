package com.verizon.billing;

class InvalidUsageException extends Exception {
	 public InvalidUsageException(String message) {
	     super(message);
	 }
	}
