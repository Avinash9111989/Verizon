package com.verizon.billing;

class CustomerNotFoundException extends Exception {
	 public CustomerNotFoundException(String message) {
	     super(message);
	 }
	}