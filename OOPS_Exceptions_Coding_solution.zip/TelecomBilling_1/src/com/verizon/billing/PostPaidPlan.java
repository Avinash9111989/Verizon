package com.verizon.billing;

class PostpaidPlan extends Plan {
	 public double getCallRate() { return 0.4; }
	 public double getSmsRate() { return 0.2; }
	 public double getDataRate() { return 8.0; }
	}

