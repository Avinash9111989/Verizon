package com.telecom.billing;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

@Configuration
public class AppConfig {

    @Bean
    public BillingService billingService() {
        return new BillingService(dataSource());
    }

    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setUrl("jdbc:mysql://localhost:3306/telecom");
        ds.setUsername("root");
        ds.setPassword("password"); // change as per your MySQL
        ds.setDriverClassName("com.mysql.cj.jdbc.Driver");
        return ds;
    }
}
