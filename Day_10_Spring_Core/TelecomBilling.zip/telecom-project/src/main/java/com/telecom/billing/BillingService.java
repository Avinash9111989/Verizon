package com.telecom.billing;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class BillingService {

    private final DataSource dataSource;

    public BillingService(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    public void generateBill(String customerId) {
        try (Connection conn = dataSource.getConnection()) {
            String sql = "SELECT name, plan_type, usage, (usage * rate) AS total FROM billing_data WHERE customer_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, customerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Customer: " + rs.getString("name"));
                System.out.println("Plan: " + rs.getString("plan_type"));
                System.out.println("Usage: " + rs.getInt("usage"));
                System.out.println("Total Bill: ₹" + rs.getDouble("total"));
            } else {
                System.out.println("Customer ID not found.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
