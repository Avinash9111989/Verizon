
package com.telecombilling;

public class BillingException extends Exception {
    public BillingException(String message) {
        super(message);
    }
}
