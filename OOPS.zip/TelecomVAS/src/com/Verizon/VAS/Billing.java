package com.Verizon.VAS;

public interface Billing {
int deduct(User u);
}
