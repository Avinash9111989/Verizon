package com.Verizon.VAS;

public abstract class VAS {
int serviceId;
abstract void subscribe(User u);
}
