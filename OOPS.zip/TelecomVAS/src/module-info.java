/**
 * 
 */
/**
 * 
 */
module TelecomVAS {
}