package com.java8.app;

public class VASUsageRecord {
    public enum UsageType { VOICE, SMS, DATA }

    private UsageType usageType;
    private String date;
    private double unitsUsed;

    public VASUsageRecord(UsageType usageType, String date, double unitsUsed) {
        this.usageType = usageType;
        this.date = date;
        this.unitsUsed = unitsUsed;
    }

    public UsageType getUsageType() { return usageType; }
    public double getUnitsUsed() { return unitsUsed; }
}

