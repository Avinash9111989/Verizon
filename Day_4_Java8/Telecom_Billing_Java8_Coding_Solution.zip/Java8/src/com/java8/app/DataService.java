package com.java8.app;

public class DataService implements VASService {
    public String getServiceName() { return "DATA"; }
    public double getRatePerUnit() { return 0.5; } // ₹0.5 per MB
}
