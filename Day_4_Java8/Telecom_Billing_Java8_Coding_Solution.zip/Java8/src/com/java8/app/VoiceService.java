package com.java8.app;

public class VoiceService implements VASService {
    public String getServiceName() { return "VOICE"; }
    public double getRatePerUnit() { return 2.0; } // ₹2 per minute
}

