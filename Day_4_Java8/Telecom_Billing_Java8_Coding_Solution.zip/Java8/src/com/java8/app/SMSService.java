package com.java8.app;

public class SMSService implements VASService {
    public String getServiceName() { return "SMS"; }
    public double getRatePerUnit() { return 1.0; } // ₹1 per SMS
}

