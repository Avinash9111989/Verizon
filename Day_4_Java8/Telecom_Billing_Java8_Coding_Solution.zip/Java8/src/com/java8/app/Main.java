package com.java8.app;

import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Customer c1 = new Customer("1001", "Avinash", "9999988888");
        c1.addUsage(new VASUsageRecord(VASUsageRecord.UsageType.VOICE, "2025-07-01", 10));
        c1.addUsage(new VASUsageRecord(VASUsageRecord.UsageType.SMS, "2025-07-01", 5));
        c1.addUsage(new VASUsageRecord(VASUsageRecord.UsageType.DATA, "2025-07-01", 300));

        Customer c2 = new Customer("1002", "Priya", "9999911111");
        c2.addUsage(new VASUsageRecord(VASUsageRecord.UsageType.VOICE, "2025-07-01", 2));
        c2.addUsage(new VASUsageRecord(VASUsageRecord.UsageType.DATA, "2025-07-01", 100));

        Customer c3 = new Customer("1003", "Ravi", "9999922222"); // No usage

        List<Customer> customers = Arrays.asList(c1, c2, c3);

        customers.forEach(BillingEngine::generateBill);
    }
}

