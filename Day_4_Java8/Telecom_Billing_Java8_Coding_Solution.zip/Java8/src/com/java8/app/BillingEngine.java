package com.java8.app;

import java.util.*;
import java.util.stream.Collectors;

public class BillingEngine {
    private static final Map<VASUsageRecord.UsageType, VASService> serviceMap = new HashMap<>();

    static {
        serviceMap.put(VASUsageRecord.UsageType.VOICE, new VoiceService());
        serviceMap.put(VASUsageRecord.UsageType.SMS, new SMSService());
        serviceMap.put(VASUsageRecord.UsageType.DATA, new DataService());
    }

    public static void generateBill(Customer customer) {
        List<VASUsageRecord> usageList = customer.getUsageList();

        Optional<List<VASUsageRecord>> optionalUsage = Optional.ofNullable(usageList);

        if (!optionalUsage.isPresent() || usageList.isEmpty()) {
            System.out.println("No usage records found for customer " + customer.getName());
            return;
        }

        Map<VASUsageRecord.UsageType, Double> totalUnits = usageList.stream()
                .collect(Collectors.groupingBy(
                        VASUsageRecord::getUsageType,
                        Collectors.summingDouble(VASUsageRecord::getUnitsUsed)
                ));

        double totalAmount = 0;
        StringJoiner joiner = new StringJoiner("\n");
        joiner.add("Monthly Bill for " + customer.getName() + " (" + customer.getPhone() + ")");
        joiner.add("-------------------------------------");

        for (VASUsageRecord.UsageType type : totalUnits.keySet()) {
            VASService service = serviceMap.get(type);
            double units = totalUnits.get(type);
            double cost = service.calculateCharge(units);
            totalAmount += cost;
            joiner.add(String.format("%-6s : ₹%.2f", type.name(), cost));
        }

        joiner.add("-------------------------------------");
        joiner.add(String.format("Total  : ₹%.2f", totalAmount));

        System.out.println(joiner);
    }
}

