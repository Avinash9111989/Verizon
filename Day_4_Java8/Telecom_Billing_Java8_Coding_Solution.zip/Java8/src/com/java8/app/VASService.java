package com.java8.app;

public interface VASService {
    String getServiceName();
    double getRatePerUnit();

    default double calculateCharge(double unitsUsed) {
        return unitsUsed * getRatePerUnit();
    }
}

