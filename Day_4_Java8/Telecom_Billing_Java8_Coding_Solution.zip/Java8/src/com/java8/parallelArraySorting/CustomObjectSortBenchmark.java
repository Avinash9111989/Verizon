package com.java8.parallelArraySorting;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;

class Employee {
    int id;
    String name;
    int salary;

    public Employee(int id, String name, int salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return id + " - " + name + " - " + salary;
    }
}

public class CustomObjectSortBenchmark {
    public static void main(String[] args) {
        int size = 500_000;
        Employee[] original = generateRandomEmployees(size);

        // Comparator: Sort by salary, then name
        Comparator<Employee> empComparator = Comparator
                .comparingInt((Employee e) -> e.salary)
                .thenComparing(e -> e.name);

        // Sequential sort
        Employee[] empSort = Arrays.copyOf(original, original.length);
        long start1 = System.nanoTime();
        Arrays.sort(empSort, empComparator);
        long end1 = System.nanoTime();
        System.out.printf("Arrays.sort() time: %.3f ms%n", (end1 - start1) / 1e6);

        // Parallel sort
        Employee[] empParallelSort = Arrays.copyOf(original, original.length);
        long start2 = System.nanoTime();
        Arrays.parallelSort(empParallelSort, empComparator);
        long end2 = System.nanoTime();
        System.out.printf("Arrays.parallelSort() time: %.3f ms%n", (end2 - start2) / 1e6);
    }

    private static Employee[] generateRandomEmployees(int size) {
        Random rand = new Random();
        String[] names = {"Alice", "Bob", "Charlie", "David", "Eva", "Frank", "Grace", "Hannah", "Ivan", "Julia"};
        Employee[] employees = new Employee[size];
        for (int i = 0; i < size; i++) {
            int id = i + 1;
            String name = names[rand.nextInt(names.length)];
            int salary = rand.nextInt(100_000);
            employees[i] = new Employee(id, name, salary);
        }
        return employees;
    }
}

