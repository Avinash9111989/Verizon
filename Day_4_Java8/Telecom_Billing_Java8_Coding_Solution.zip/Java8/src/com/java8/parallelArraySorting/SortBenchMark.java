package com.java8.parallelArraySorting;

import java.util.Arrays;
import java.util.Random;

public class SortBenchMark {
    public static void main(String[] args) {
        int size = 1_000_000;
        int[] original = new Random().ints(size, 0, 1_000_000).toArray();

        // Copy for sequential sort
        int[] array1 = Arrays.copyOf(original, original.length);
        long start1 = System.nanoTime();
        Arrays.sort(array1);
        long end1 = System.nanoTime();
        System.out.printf("Arrays.sort() time: %.3f ms%n", (end1 - start1) / 1e6);

        // Copy for parallel sort
        int[] array2 = Arrays.copyOf(original, original.length);
        long start2 = System.nanoTime();
        Arrays.parallelSort(array2);
        long end2 = System.nanoTime();
        System.out.printf("Arrays.parallelSort() time: %.3f ms%n", (end2 - start2) / 1e6);
    }
}

