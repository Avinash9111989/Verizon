package com.java8.parallelArraySorting;

import java.util.Arrays;

public class ParallelSortDemo {
    public static void main(String[] args) {
        int[] numbers = {5, 2, 8, 3, 1, 9, 4, 7, 6};

        System.out.println("Before sort: " + Arrays.toString(numbers));

        Arrays.parallelSort(numbers);

        System.out.println("After sort: " + Arrays.toString(numbers));
    }
}

